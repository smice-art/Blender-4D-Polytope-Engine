"""4D Polytope's own card: which controls show, in what order, under
which branch. All drawing, palette and modal plumbing live in
`card_kit.py`, shared with other add-ons -- this file only walks
`POLYTOPE4D_PG_settings`, the same tree the old
`VIEW3D_PT_polytope4d.draw()` walked.
"""

import bpy

from . import card_kit


def _build(context, region, layout):
    obj = context.object
    layout.title("4D Polytope")

    if obj is None or obj.type != "MESH" or not obj.polytope4d.is_engine:
        layout.note("No engine object selected")
        layout.button("Add 4D Polytope", "mesh.polytope4d_add")
        return

    props = obj.polytope4d

    layout.section("Form")
    layout.cycle(props, "form")
    form = props.form
    if form == "UNIFORM":
        layout.cycle(props, "family")
        layout.cycle(props, "wythoff_rings")
    elif form == "PRISM":
        layout.cycle(props, "seed")
        layout.field(props, "seed_height")
    elif form == "DUOPRISM":
        layout.field(props, "duo_p")
        layout.field(props, "duo_q")
    else:
        layout.cycle(props, "kind")

    layout.section("Edges")
    layout.cycle(props, "style")
    if props.style == "STRAIGHT":
        layout.field(props, "proj_dist")

    layout.section("Render")
    layout.cycle(props, "render")
    render = props.render
    if render == "LEONARDO":
        layout.field(props, "border")
        layout.field(props, "panel_thickness")
        layout.switch(props, "taper")
    elif render == "WIREFRAME":
        layout.field(props, "arc_segments")
    elif render == "CURVE":
        layout.field(props, "arc_segments")
        layout.field(props, "curve_bevel_depth")
        layout.field(props, "curve_bevel_resolution")
        layout.switch(props, "taper")
    else:
        layout.field(props, "arc_segments")
        layout.field(props, "radius")
        if render == "BALLSTICK":
            layout.field(props, "sides")
        layout.switch(props, "taper")
        if render == "BALLSTICK":
            layout.field(props, "sphere_factor")
            layout.cycle(props, "vertex_shape")
    layout.field(props, "scale")

    layout.section("Rotation")
    for key in ("rot_xw", "rot_yw", "rot_zw", "rot_xy"):
        layout.field(props, key, suffix="°")

    layout.section("Cells")
    layout.switch(props, "half")
    if form == "REGULAR":
        layout.switch(props, "dual_compound")
        if props.kind == "CELL120":
            layout.field(props, "rings")
            if props.rings > 0:
                layout.field(props, "ring_cell_scale")
                layout.switch(props, "rings_only")

    layout.section("Build")
    layout.switch(props, "auto_update")
    layout.button("Rebuild", "object.polytope4d_rebuild")
    layout.note("%.2fs -- %d verts, %d edges" % (
        props.last_build_time, props.last_build_nv, props.last_build_ne))
    layout.button("Reset to Defaults", "object.polytope4d_reset_defaults")
    layout.button("Detach from Engine", "object.polytope4d_detach")


CARD = card_kit.Card(tab_category="4D Polytope")


class OBJECT_OT_polytope4d_card(bpy.types.Operator):
    """Give the viewport card a mouse. Started on its own, never by hand."""

    bl_idname = "object.polytope4d_card"
    bl_label = "4D Polytope Card"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        return CARD.invoke(self, context, event)

    def modal(self, context, event):
        return CARD.modal(self, context, event)

    def cancel(self, context):
        CARD.cancel(self)


def register_draw():
    CARD.register_draw()


def clear():
    CARD.clear()


def is_on():
    return CARD.is_on()


def register():
    bpy.utils.register_class(OBJECT_OT_polytope4d_card)
    CARD.start(OBJECT_OT_polytope4d_card.bl_idname, _build)


def unregister():
    CARD.stop()
    bpy.utils.unregister_class(OBJECT_OT_polytope4d_card)
