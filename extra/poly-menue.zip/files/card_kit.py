"""Reusable scaffolding for a viewport-drawn N-panel replacement.

Shared across add-ons: the palette, the `gpu`/`blf` drawing primitives,
the RNA-driven widget helpers (a control needs only a PropertyGroup
instance and a property name -- its range, its enum items and its
current value all come from the property's own `bl_rna`, not from a
hand-copied list), the state machine behind a single card, and the
modal plumbing that lets it own the mouse only while the pointer sits
over it.

What is NOT here, on purpose: the widget tree itself. Every add-on's
card looks different because every add-on's settings are different --
that part stays in a small `*_card.py` next to each add-on's
`__init__.py`, built with the `Layout` object below.

Minimal usage from an add-on:

    import bpy
    from . import card_kit

    def _build(context, region, layout):
        obj = context.object
        if obj is None or not obj.my_settings.is_engine:
            layout.note("No engine object selected")
            layout.button("Add Thing", "mesh.my_thing_add")
            return
        props = obj.my_settings
        layout.section("Shape")
        layout.cycle(props, "kind")
        layout.field(props, "radius")
        layout.switch(props, "smooth")

    CARD = card_kit.Card(tab_category="My Add-on")

    class MYADDON_OT_card(bpy.types.Operator):
        bl_idname = "myaddon.card"
        bl_label = "My Add-on Card"
        bl_options = {"INTERNAL"}

        def invoke(self, context, event):
            return CARD.invoke(self, context, event)

        def modal(self, context, event):
            return CARD.modal(self, context, event)

        def cancel(self, context):
            CARD.cancel(self)

    def register():
        bpy.utils.register_class(MYADDON_OT_card)
        CARD.start(MYADDON_OT_card.bl_idname, _build)

    def unregister():
        CARD.stop()
        bpy.utils.unregister_class(MYADDON_OT_card)

A stub `bpy.types.Panel` with `bl_category` equal to `tab_category`,
`bl_options = {'HIDE_HEADER'}` and a `draw()` that does nothing still
has to be registered by the add-on itself -- that is what keeps the
sidebar tab open for the card to sit on, and it is one add-on-specific
class name (bl_idname must be unique), so it is not something this
module can register on anyone's behalf.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader


# -- palette ----------------------------------------------------------------

@dataclass(frozen=True)
class Palette:
    accent: tuple = (0.357, 0.678, 1.000, 1.0)          # #5BADFF
    accent_hover: tuple = (0.494, 0.749, 1.000, 1.0)
    on_accent: tuple = (0.04, 0.09, 0.16, 1.0)           # text on the accent

    card_bg: tuple = (0.098, 0.102, 0.114, 1.0)
    edge: tuple = (1.0, 1.0, 1.0, 0.08)

    # Solid, not translucent-white-over-dark: a low-alpha white looked
    # right in a mock-up and rendered as a near-opaque pale box in
    # Blender's own viewport compositing. Opaque colours chosen to
    # land where the translucent ones were *meant* to land sidestep
    # that gap entirely, on any machine.
    control: tuple = (0.17, 0.19, 0.22, 1.0)
    control_hover: tuple = (0.21, 0.24, 0.28, 1.0)
    track: tuple = (0.24, 0.26, 0.30, 1.0)

    text: tuple = (0.92, 0.92, 0.94, 1.0)
    text_dim: tuple = (0.56, 0.56, 0.60, 1.0)

    # The enum "chip" gets its own pair rather than reusing text/control:
    # a pale tint behind, dark ink in front, so a dropdown-style control
    # reads at a glance instead of blending into every other dark box.
    cycle_bg: tuple = (0.80, 0.86, 0.95, 1.0)
    cycle_bg_hover: tuple = (0.87, 0.92, 0.98, 1.0)
    cycle_text: tuple = (0.06, 0.10, 0.20, 1.0)
    cycle_text_dim: tuple = (0.24, 0.31, 0.42, 1.0)


DEFAULT_PALETTE = Palette()


# -- reading a control's own RNA, instead of a hard-coded list --------------

def _num_range(props, key):
    rna = props.bl_rna.properties[key]
    lo = rna.soft_min if rna.soft_min > -1.0e5 else rna.hard_min
    hi = rna.soft_max if rna.soft_max < 1.0e5 else rna.hard_max
    decimals = rna.precision if rna.type == "FLOAT" else 0
    return lo, hi, decimals


def _enum_labels(props, key):
    return [(it.identifier, it.name) for it in props.bl_rna.properties[key].enum_items]


# -- drawing primitives -------------------------------------------------

def _round_rect(x, y, w, h, r, segments=6):
    """A filled rounded rectangle as one triangle fan around its centre."""
    r = max(0.0, min(r, w * 0.5, h * 0.5))
    if r <= 0.5:
        return [(x, y), (x + w, y), (x + w, y + h),
                (x, y), (x + w, y + h), (x, y + h)]
    centers = ((x + w - r, y + r), (x + w - r, y + h - r),
               (x + r, y + h - r), (x + r, y + r))
    verts = []
    for i, (cx, cy) in enumerate(centers):
        a0 = i * (math.pi * 0.5) - math.pi * 0.5
        for s in range(segments + 1):
            a = a0 + (math.pi * 0.5) * (s / segments)
            verts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    mx, my = x + w * 0.5, y + h * 0.5
    tris = []
    for i in range(len(verts)):
        tris.extend(((mx, my), verts[i], verts[(i + 1) % len(verts)]))
    return tris


def _fill(shader, x, y, w, h, r, color):
    if w <= 0.0 or h <= 0.0:
        return
    batch = batch_for_shader(shader, "TRIS", {"pos": _round_rect(x, y, w, h, r)})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _text(s, x, y, size, color, scale, align="left"):
    blf.size(0, max(1.0, size * scale))
    if align != "left":
        tw, _th = blf.dimensions(0, s)
        x = x - tw if align == "right" else x - tw * 0.5
    blf.color(0, *color)
    blf.position(0, x, y, 0)
    blf.draw(0, s)


def _fit_text(s, max_w, size, scale, min_size=9.0):
    """Shrink the point size, then truncate with an ellipsis, to fit max_w."""
    sz = size
    while sz > min_size:
        blf.size(0, sz * scale)
        w, _h = blf.dimensions(0, s)
        if w <= max_w:
            return s, sz
        sz -= 1.0
    text = s
    while len(text) > 1:
        blf.size(0, sz * scale)
        w, _h = blf.dimensions(0, text + "…")
        if w <= max_w:
            return text + "…", sz
        text = text[:-1]
    return text, sz


def _run_op(idname):
    mod, name = idname.split(".", 1)
    try:
        getattr(getattr(bpy.ops, mod), name)("EXEC_DEFAULT")
    except Exception:
        pass


def _redraw(context, area=None):
    for win in context.window_manager.windows:
        for a in win.screen.areas:
            if area is not None and a is not area:
                continue
            if a.type == "VIEW_3D":
                a.tag_redraw()


def _hit(widgets, mx, my):
    for i, w in enumerate(widgets):
        x, y, ww, hh = w["rect"]
        if x <= mx <= x + ww and y <= my <= y + hh:
            return i
    return None


# -- layout: what an add-on's build_fn calls, top to bottom ----------------

class Layout:
    """Accumulates one card's widgets top-down. Every control here takes
    a PropertyGroup instance and a property name -- nothing about a
    specific add-on's settings is hard-coded."""

    ROW = 28.0
    GAP = 8.0

    def __init__(self, x, top, width, pad=14.0, scroll=0.0):
        self.x = x
        self.top = top
        self.pad = pad
        self.width = width
        self.inner = width - pad * 2.0
        self.left = x + pad
        self.cursor = top - pad + scroll
        self.widgets = []

    def _put(self, kind, h, gap=None, **kw):
        gap = self.GAP if gap is None else gap
        kw["kind"] = kind
        kw["rect"] = (self.left, self.cursor - h, self.inner, h)
        self.widgets.append(kw)
        self.cursor -= h + gap
        return kw

    def title(self, text):
        self._put("title", 22.0, gap=10.0, text=text)

    def section(self, text):
        self._put("section", 15.0, gap=4.0, text=text.upper())

    def note(self, text):
        self._put("note", 15.0, gap=10.0, text=text)

    def cycle(self, props, key, label=None):
        rna = props.bl_rna.properties[key]
        self._put("cycle", 32.0, key=key, props=props, label=label or rna.name)

    def switch(self, props, key, label=None):
        rna = props.bl_rna.properties[key]
        self._put("switch", 26.0, key=key, props=props, label=label or rna.name)

    def field(self, props, key, suffix=""):
        rna = props.bl_rna.properties[key]
        self._put("field", 20.0, gap=2.0, key=key, props=props,
                   label=rna.name, suffix=suffix)
        self._put("bar", 12.0, key=key, props=props)

    def button(self, text, idname):
        self._put("button", self.ROW, text=text, idname=idname)

    def result(self):
        card = (self.x, self.cursor - self.pad, self.width,
                self.top - self.cursor + self.pad)
        return self.widgets, card


# -- the card itself -------------------------------------------------

class Card:
    """One viewport card: state, drawing and the modal plumbing behind it.

    `tab_category` must match the `bl_category` of the add-on's own
    empty stub Panel -- that is how the card knows the sidebar is open
    on its tab rather than someone else's.
    """

    def __init__(self, tab_category, palette=DEFAULT_PALETTE, card_w=300.0,
                 tab_strip=28.0, pad=14.0, corner_card=14.0, corner_ctl=8.0):
        self.tab_category = tab_category
        self.palette = palette
        self.card_w = card_w
        self.tab_strip = tab_strip
        self.pad = pad
        self.corner_card = corner_card
        self.corner_ctl = corner_ctl
        self.build_fn = None
        self._operator_idname = None
        self._driver_key = "cardkit_%s_handle" % abs(hash(tab_category))
        self.state = {
            "handle": None, "modal": False, "token": 0, "quit": False,
            "widgets": [], "card": (0.0, 0.0, 0.0, 0.0), "hover": None,
            "drag": None, "scroll": 0.0, "was_up": False, "beat": 0.0,
        }

    # -- visibility --

    def visible(self, context, area=None):
        if area is None:
            area = getattr(context, "area", None)
        if area is None or area.type != "VIEW_3D":
            return False
        space = area.spaces.active
        if not getattr(space, "show_region_ui", False):
            return False
        for region in area.regions:
            if region.type == "UI":
                if region.width < 60:      # dragged shut, tab remembered anyway
                    return False
                return (getattr(region, "active_panel_category", "")
                        == self.tab_category)
        return False

    def showing(self):
        try:
            for win in bpy.context.window_manager.windows:
                for area in win.screen.areas:
                    if area.type != "VIEW_3D":
                        continue
                    space = area.spaces.active
                    if not getattr(space, "show_region_ui", False):
                        continue
                    for r in area.regions:
                        if (r.type == "UI" and r.width >= 60
                                and getattr(r, "active_panel_category", "")
                                == self.tab_category):
                            return True
        except Exception:
            pass
        return False

    # -- layout / draw --

    def _build(self, context, region):
        scale = context.preferences.system.ui_scale or 1.0
        heads = 0.0
        area = getattr(context, "area", None)
        if area is not None:
            for r in area.regions:
                if r.type in {"HEADER", "TOOL_HEADER"}:
                    heads += r.height
        x = region.width / scale - self.tab_strip - self.card_w
        top = (region.height - heads) / scale - 8.0
        layout = Layout(x, top, self.card_w, pad=self.pad,
                        scroll=self.state["scroll"])
        self.build_fn(context, region, layout)
        return layout.result()

    def draw(self):
        context = bpy.context
        region = context.region
        if region is None or not self.visible(context):
            return
        widgets, card = self._build(context, region)
        self.state["widgets"] = widgets
        self.state["card"] = card
        if not widgets:
            return

        pal = self.palette
        scale = context.preferences.system.ui_scale or 1.0
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        gpu.state.blend_set("ALPHA")
        shader.bind()

        def box(rect, r, color):
            x, y, w, h = rect
            _fill(shader, x * scale, y * scale, w * scale, h * scale,
                  r * scale, color)

        cx, cy, cw, ch = card
        box((cx - 1.0, cy - 1.0, cw + 2.0, ch + 2.0), self.corner_card + 1.0,
            pal.edge)
        box((cx, cy, cw, ch), self.corner_card, pal.card_bg)

        clipped = self.state["scroll"] != 0.0
        if clipped:
            gpu.state.scissor_test_set(True)
            gpu.state.scissor_set(int(cx * scale) - 2, int(cy * scale) - 2,
                                  int(cw * scale) + 4, int(ch * scale) + 4)

        hover = self.state.get("hover")
        for i, w in enumerate(widgets):
            kind = w["kind"]
            x, y, ww, hh = w["rect"]
            lit = (i == hover)

            if kind == "title":
                _text(w["text"], x * scale, (y + 4.0) * scale, 15.0,
                      pal.text, scale)
            elif kind == "section":
                _text(w["text"], x * scale, (y + 3.0) * scale, 9.5,
                      pal.text_dim, scale)
            elif kind == "note":
                _text(w["text"], x * scale, (y + 2.0) * scale, 10.5,
                      pal.text_dim, scale)
            elif kind == "switch":
                on = bool(getattr(w["props"], w["key"]))
                _text(w["label"], x * scale, (y + hh * 0.5 - 6.0) * scale,
                      12.0, pal.text, scale)
                tw_, th_ = 34.0, 18.0
                tx, ty = x + ww - tw_, y + (hh - th_) * 0.5
                box((tx, ty, tw_, th_), th_ * 0.5,
                    pal.accent if on else (pal.control_hover if lit else pal.track))
                kr = th_ * 0.5 - 2.0
                kx = (tx + tw_ - kr - 2.0) if on else (tx + kr + 2.0)
                box((kx - kr, ty + 2.0, kr * 2.0, kr * 2.0), kr,
                    (1.0, 1.0, 1.0, 1.0))
            elif kind == "cycle":
                box((x, y, ww, hh), self.corner_ctl,
                    pal.cycle_bg_hover if lit else pal.cycle_bg)
                cur = getattr(w["props"], w["key"])
                label = next((n for ident, n in _enum_labels(w["props"], w["key"])
                             if ident == cur), str(cur))
                _text(w["label"], (x + 10.0) * scale, (y + hh - 12.0) * scale,
                      8.5, pal.cycle_text_dim, scale)
                fit, sz = _fit_text(label, (ww - 56.0) * scale, 12.0, scale)
                _text(fit, (x + ww * 0.5) * scale, (y + 6.0) * scale, sz,
                      pal.cycle_text, scale, align="center")
                _text("‹", (x + 15.0) * scale, (y + hh * 0.5 - 5.0) * scale,
                      13.0, pal.cycle_text_dim, scale)
                _text("›", (x + ww - 22.0) * scale, (y + hh * 0.5 - 5.0) * scale,
                      13.0, pal.cycle_text_dim, scale)
            elif kind == "field":
                val = getattr(w["props"], w["key"])
                _lo, _hi, decimals = _num_range(w["props"], w["key"])
                shown = ("%.*f" % (decimals, val)) if decimals else str(int(round(val)))
                _text(w["label"], x * scale, (y + 2.0) * scale, 11.0,
                      pal.text, scale)
                _text(shown + w.get("suffix", ""), (x + ww) * scale,
                      (y + 2.0) * scale, 11.0, pal.text_dim, scale,
                      align="right")
            elif kind == "bar":
                val = getattr(w["props"], w["key"])
                lo, hi, _d = _num_range(w["props"], w["key"])
                t = 0.0 if hi <= lo else max(0.0, min(1.0, (val - lo) / (hi - lo)))
                box((x, y, ww, hh), hh * 0.5, pal.track)
                box((x, y, max(hh, ww * t), hh), hh * 0.5,
                    pal.accent_hover if self.state.get("drag") == i else pal.accent)
            elif kind == "button":
                box((x, y, ww, hh), self.corner_ctl,
                    pal.accent_hover if lit else pal.accent)
                _text(w["text"], (x + ww * 0.5) * scale,
                      (y + hh * 0.5 - 5.0) * scale, 12.0, pal.on_accent,
                      scale, align="center")

        if clipped:
            gpu.state.scissor_test_set(False)
        gpu.state.blend_set("NONE")

    # -- actions --

    def _fire(self, context, w, mx):
        kind = w["kind"]
        if kind == "button":
            _run_op(w["idname"])
            return
        props, key = w.get("props"), w.get("key")
        if props is None or key is None:
            return
        if kind == "switch":
            setattr(props, key, not getattr(props, key))
        elif kind == "cycle":
            ids = [ident for ident, _n in _enum_labels(props, key)]
            cur = getattr(props, key)
            idx = ids.index(cur) if cur in ids else 0
            x, _y, _ww, _hh = w["rect"]
            step = -1 if mx < x + 26.0 else 1
            setattr(props, key, ids[(idx + step) % len(ids)])
        elif kind == "bar":
            lo, hi, decimals = _num_range(props, key)
            x, _y, ww, _hh = w["rect"]
            t = 0.0 if ww <= 0 else max(0.0, min(1.0, (mx - x) / ww))
            val = lo + t * (hi - lo)
            setattr(props, key,
                    round(val, decimals) if decimals else int(round(val)))

    # -- modal plumbing: the add-on's own Operator delegates here --

    def invoke(self, operator, context, event):
        st = self.state
        if st["modal"]:
            return {"CANCELLED"}
        st["modal"] = True
        st["token"] += 1
        operator._token = st["token"]
        st["beat"] = time.time()
        context.window_manager.modal_handler_add(operator)
        return {"RUNNING_MODAL"}

    def cancel(self, operator):
        if getattr(operator, "_token", None) == self.state.get("token"):
            self.state["modal"] = False

    def modal(self, operator, context, event):
        st = self.state
        if getattr(operator, "_token", None) != st["token"] or st["quit"]:
            st["modal"] = False
            return {"CANCELLED"}
        st["beat"] = time.time()

        area = getattr(context, "area", None)
        region = None
        if area is not None and area.type == "VIEW_3D":
            region = next((r for r in area.regions if r.type == "WINDOW"), None)

        if region is None or not self.visible(context, area):
            if st["hover"] is not None or st["drag"] is not None:
                st["hover"] = None
                st["drag"] = None
                _redraw(context, area)
            return {"PASS_THROUGH"}

        scale = context.preferences.system.ui_scale or 1.0
        mx = (event.mouse_x - region.x) / scale
        my = (event.mouse_y - region.y) / scale

        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            x, y, w, h = st["card"]
            if x <= mx <= x + w and y <= my <= y + h:
                step = 26.0 if event.type == "WHEELDOWNMOUSE" else -26.0
                st["scroll"] = max(-3000.0, min(300.0, st["scroll"] + step))
                _redraw(context, area)
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}

        widgets = st["widgets"]
        over = _hit(widgets, mx, my)

        if event.type == "MOUSEMOVE":
            if st["drag"] is not None:
                self._fire(context, widgets[st["drag"]], mx)
                _redraw(context, area)
                return {"RUNNING_MODAL"}
            if over != st["hover"]:
                st["hover"] = over
                _redraw(context, area)
            return {"RUNNING_MODAL"} if over is not None else {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            if over is None:
                return {"PASS_THROUGH"}
            w = widgets[over]
            if w["kind"] == "bar":
                st["drag"] = over
            self._fire(context, w, mx)
            _redraw(context, area)
            return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            if st["drag"] is not None:
                st["drag"] = None
                _redraw(context, area)
            return {"RUNNING_MODAL"} if over is not None else {"PASS_THROUGH"}

        return {"RUNNING_MODAL"} if over is not None else {"PASS_THROUGH"}

    # -- lifecycle --

    def _drop_stale(self):
        ns = bpy.app.driver_namespace
        old = ns.pop(self._driver_key, None)
        if old is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(old, "WINDOW")
            except Exception:
                pass

    def register_draw(self):
        if self.state["handle"] is None:
            self._drop_stale()
            self.state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
                self.draw, (), "WINDOW", "POST_PIXEL")
            bpy.app.driver_namespace[self._driver_key] = self.state["handle"]
        self.state["quit"] = False

    def clear(self):
        if self.state["handle"] is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self.state["handle"],
                                                          "WINDOW")
            except Exception:
                pass
        self.state["handle"] = None
        bpy.app.driver_namespace.pop(self._driver_key, None)
        self.state["widgets"] = []
        self.state["hover"] = None
        self.state["drag"] = None

    def is_on(self):
        return bool(self.state["handle"])

    def _keep_alive(self):
        """Restart the modal if Blender ever drops it (a file load, a
        closed window) while the tab is still open."""
        st = self.state
        if st["quit"]:
            return None
        now = time.time()
        if st["modal"] and now - st["beat"] > 5.0 and self.showing():
            st["modal"] = False
        up = self.showing()
        if up != st["was_up"]:
            st["was_up"] = up
            _redraw(bpy.context)
        if not st["modal"] and up and self._operator_idname:
            mod, name = self._operator_idname.split(".", 1)
            for win in bpy.context.window_manager.windows:
                for area in win.screen.areas:
                    if area.type != "VIEW_3D":
                        continue
                    region = next((r for r in area.regions if r.type == "WINDOW"),
                                  None)
                    if region is None:
                        continue
                    try:
                        with bpy.context.temp_override(window=win, area=area,
                                                       region=region):
                            getattr(getattr(bpy.ops, mod), name)("INVOKE_DEFAULT")
                    except Exception:
                        pass
                    break
                if st["modal"]:
                    break
        return 0.25

    def start(self, operator_idname, build_fn):
        """Called from the add-on's own register(): the operator's
        bl_idname (for the keep-alive timer to restart it) and the
        function that lays the card's widgets out."""
        self.build_fn = build_fn
        self._operator_idname = operator_idname
        self.state["quit"] = False
        self.register_draw()
        if not bpy.app.timers.is_registered(self._keep_alive):
            bpy.app.timers.register(self._keep_alive, first_interval=0.5,
                                    persistent=True)

    def stop(self):
        self.state["quit"] = True
        try:
            if bpy.app.timers.is_registered(self._keep_alive):
                bpy.app.timers.unregister(self._keep_alive)
        except Exception:
            pass
        try:
            self.clear()
        except Exception:
            pass
